###CWRU Worlds for STDR Simulator.

Map installation (requires admin)

1. `roscd stdr_resources/maps` 
2. `sudo cp ~/ros_workspace/cwru_376_GROUPNAME/2nd_floor_one_door_stage.pgm .`
3. `sudo cp ~/ros_workspace/cwru_376_GROUPNAME/2nd_floor_one_door.yaml .`

Launch the world

`roslaunch cwru_376_launchers stdr_glennan_2.launch`
