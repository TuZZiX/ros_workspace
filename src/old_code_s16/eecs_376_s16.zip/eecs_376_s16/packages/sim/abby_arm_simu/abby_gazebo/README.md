# abby_gazebo

Used only for launch file for irb120 gazebo simulation.  References irb120.xacro and corresponding simulated controller.


    
