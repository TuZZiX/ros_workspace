# abb_common

Wsn copied this info from swri-ros-pkg/abb.
This folder is only used now for the meshes, referenced within abby_description xacro

