# abby_control

package used only to specify controller gains for simulation of joint position controllers in Gazebo
Launch file loads controllers into Gazebo and starts "robot_state_publisher".  This launch file is included in abby_gazebo/abby_world.launch
    
