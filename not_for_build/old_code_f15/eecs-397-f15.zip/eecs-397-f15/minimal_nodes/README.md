# MINIMAL_NODES
here are source examples following the notes "Intro to ROS v4", which can be found one level up in this
directory under "Documents."  Includes a minimal publisher, minimal subscriber, minimal simulator and
minimal controller.  Also contains an example launch file.
